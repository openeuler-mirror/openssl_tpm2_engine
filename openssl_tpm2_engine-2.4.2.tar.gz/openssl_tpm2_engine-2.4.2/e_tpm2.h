#ifndef _E_TPM2_COMMON_H
#define _E_TPM2_COMMON_H

#include "e_tpm2-rsa.h"
#include "e_tpm2-ecc.h"

#define TPM2_ENGINE_EX_DATA_UNINIT		-1

extern char *srk_auth;

#endif
